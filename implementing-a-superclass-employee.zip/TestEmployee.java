// TestEmployee.java
public class TestEmployee {
    public static void main(String[] args) {
        // Test Employee class
        Employee emp = new Employee();
        emp.setFirstName("John");
        emp.setLastName("Doe");
        emp.setEmployeeID(123);
        emp.employeeSummary();

        // Test Manager class
        Manager manager = new Manager();
        manager.setFirstName("Jane");
        manager.setLastName("Smith");
        manager.setEmployeeID(456);
        manager.setDepartment("Sales");
        manager.employeeSummary();
    }
}
